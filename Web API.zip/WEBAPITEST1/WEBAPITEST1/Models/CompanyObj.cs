﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WEBAPITEST1.Models
{
    public class CompanyObj
    {
        public string CompanyID { get; set; }
        public string CompanyName { get; set; }

        public string UEN { get; set; }
        public string CompanyType { get; set; }
        public string Address { get; set; }

        public string PostalCode { get; set; }

        public string CountryOps { get; set; }
        public string BizNature { get; set; }
        public string BizDesc { get; set; }

        public string BizDescOther { get; set; }

        public string CompanyShtName { get; set; }
        public string AddressCty { get; set; }

        public string extUrlLink { get; set; }
        public string extUserID { get; set; }
        public string purpose { get; set; }

        public CompanyObj() { }

        public CompanyObj(string companyID, string companyName)
        {
            this.CompanyID = companyID;
            this.CompanyName = companyName;
        }
        public CompanyObj(string companyID, string companyName, string extURLLink, string extUID, string purp)
        {
            this.CompanyID = companyID;
            this.CompanyName = companyName;
            this.extUrlLink = extURLLink;
            this.extUserID = extUID;
            this.purpose = purp;
        }


        public CompanyObj(string companyID, string companyName, string uen, string companyType, string address, string postalCode)
        {
            this.CompanyID = companyID;
            this.CompanyName = companyName;
            this.UEN = uen;
            this.CompanyType = companyType;
            this.Address = address;
            this.PostalCode = postalCode;
        }
        public CompanyObj(string companyID, string companyName, string uen, string companyType, string address, string postalCode, string countryOps, string bizNature, string bizDesc, string companyShtName, string addressCty)
        {
            this.CompanyID = companyID;
            this.CompanyName = companyName;
            this.UEN = uen;
            this.CompanyType = companyType;
            this.Address = address;
            this.PostalCode = postalCode;
            this.CountryOps = countryOps;
            this.BizNature = bizNature;
            this.BizDesc = bizDesc;
            this.CompanyShtName = companyShtName;
            this.AddressCty = addressCty;
        }

        public CompanyObj(string companyID, string companyName, string uen, string companyType, string address, string postalCode, string countryOps, string bizNature, string bizDesc, string companyShtName, string addressCty, string bizDescOther)
        {
            this.CompanyID = companyID;
            this.CompanyName = companyName;
            this.UEN = uen;
            this.CompanyType = companyType;
            this.Address = address;
            this.PostalCode = postalCode;
            this.CountryOps = countryOps;
            this.BizNature = bizNature;
            this.BizDesc = bizDesc;
            this.CompanyShtName = companyShtName;
            this.AddressCty = addressCty;
            this.BizDescOther = bizDescOther;
        }

        //public CompanyObj(string companyID, string companyName, string uen, string companyType, string address, string postalCode, string countryOps, string bizNature, string bizDesc, string companyShtName, string addressCty, string bizDescOther, string extUrl, string extUID)
        //{
        //    this.CompanyID = companyID;
        //    this.CompanyName = companyName;
        //    this.UEN = uen;
        //    this.CompanyType = companyType;
        //    this.Address = address;
        //    this.PostalCode = postalCode;
        //    this.CountryOps = countryOps;
        //    this.BizNature = bizNature;
        //    this.BizDesc = bizDesc;
        //    this.CompanyShtName = companyShtName;
        //    this.AddressCty = addressCty;
        //    this.BizDescOther = bizDescOther;
        //    this.extUrlLink = extUrl;
        //    this.extUserID = extUID;
        //}
        public CompanyObj(string companyID, string companyName, string uen, string companyType, string address, string postalCode, string countryOps, string bizNature, string bizDesc, string companyShtName, string addressCty, string bizDescOther, string extUrl, string extUID, string purp)
        {
            this.CompanyID = companyID;
            this.CompanyName = companyName;
            this.UEN = uen;
            this.CompanyType = companyType;
            this.Address = address;
            this.PostalCode = postalCode;
            this.CountryOps = countryOps;
            this.BizNature = bizNature;
            this.BizDesc = bizDesc;
            this.CompanyShtName = companyShtName;
            this.AddressCty = addressCty;
            this.BizDescOther = bizDescOther;
            this.extUrlLink = extUrl;
            this.extUserID = extUID;
            this.purpose = purp;
        }
        public CompanyObj(string companyID, string companyName, string companyShtname, string address, string postalCode, string country, string companyType, string companyTypeOther, string bizSector, string bizSectorOther, string uen, string extUrl, string extUID, string purp)
        {
            this.CompanyID = companyID;
            this.CompanyName = companyName;
            this.CompanyType = companyType;
            this.Address = address;
            this.PostalCode = postalCode;
            this.CountryOps = country;
            this.BizDesc = bizSector;
            this.CompanyShtName = companyShtname;
            this.AddressCty = address;
            this.BizDescOther = bizSectorOther;
            this.UEN = uen;
            this.extUrlLink = extUrl;
            this.extUserID = extUID;
            this.purpose = purp;
        }

        // Nelwy added in
        public CompanyObj(string purp)
        {
            this.purpose = purp;
        }

    }
}